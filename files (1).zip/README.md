# ACE Player Passport 🎾

> Protótipo interativo do sistema de progressão gamificada para academias de tênis.

Desenvolvido pela **Raw Tennis Academy** (Brasília, Brasil) como base para validação com treinadores e desenvolvimento do produto final.

---

## O que é

O ACE Player Passport é um app B2B SaaS para academias de tênis que combina:

- **Skill Avatar** — boneco do tenista que se revela progressivamente conforme o aluno evolui
- **Ficha de Avaliação Digital** — baseada no manual oficial de avaliações por pulseira
- **Quiz com IA** — perguntas geradas dinamicamente em 6 categorias e 4 níveis de dificuldade
- **Avaliação por Áudio + IA** — coach fala, a IA identifica os critérios automaticamente
- **Requisitos por Nível** — barras de progresso para técnico, tático, físico e mental
- **Testes Físicos ACE** — bateria estruturada por faixa etária (3-5, 5-7, 8-10 anos)
- **Cadastro de Alunos** — com turmas, horários, dias e coach
- **Turmas & Calendário** — visão semanal com detalhes de cada turma

---

## Status

🟡 **Protótipo em validação** — em teste com treinadores da Raw Tennis Academy.

---

## Tecnologia (protótipo)

- HTML + CSS + JavaScript (single file, sem dependências)
- PWA — instalável na tela inicial do celular
- Integração com API Claude (Anthropic) para geração de perguntas e avaliação por IA

---

## Uso

Este repositório contém exclusivamente o protótipo para fins de validação interna.  
O código-fonte não está disponível para uso, cópia ou distribuição.

Veja o arquivo `LICENSE` para mais informações.

---

## Contato

Raw Tennis Academy · Clube do Exército · Brasília, DF  
Para mais informações: rawtennis.com.br

---

*"Transformando o desenvolvimento do tenista com tecnologia e metodologia."*
